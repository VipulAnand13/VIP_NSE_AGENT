---
name: trader-news-NSE
description: >-
  News Monitor for NSE (India). Yahoo Finance headlines per .NS ticker and distance from yesterday's close, new items only, in IST. SEC filings are not used; for NSE corporate announcements Claude searches the web. Use for 'any news on TCS', 'why is INFY moving', 'morning briefing for my watchlist'.
argument-hint: "[tickers]"
---

# trader-news-NSE

A chart can look perfect and still be about to gap on an earnings date, a
halt or a lawsuit. Before a setup becomes a trade, this skill reads the two
feeds that carry those first, for every stock on the watchlist, and tells you
only what is new. It also prints how far each stock has moved today, so a
headline and a move sit side by side.

Tool in this folder (standard library Python, no keys):

```bash
python3 "${CLAUDE_SKILL_DIR}/news.py"                         # watchlist + plan + portfolio
python3 "${CLAUDE_SKILL_DIR}/news.py" --tickers RELIANCE NVDA --hours 12
python3 "${CLAUDE_SKILL_DIR}/news.py" --no-sec --json
```

## What it reads and writes

| file / feed | what |
| --- | --- |
| `--tickers`, else `trader/watchlist.json` | the scanner's hits (trader-scanner-NSE) |
| `trader/plan.json` | the trade you are planning (trader-exit-NSE) |
| `trader/portfolio.json` | what you hold (the broker step (not in this NSE edition) records fills there) |
| Yahoo Finance headline RSS | `https://feeds.finance.yahoo.com/rss/2.0/headline?s=RELIANCE&region=US&lang=en-US` |
| Yahoo Finance chart endpoint | the last price against yesterday's close (unofficial, can lag) |
| SEC EDGAR company Atom feed | 8-K by default (`--forms 8-K,10-Q` for more); needs `sec_user_agent` in `trader/config.json` or `SEC_USER_AGENT`, else filings are skipped with a note |
| `trader/state/news.json` | what has been shown (kept 30 days) and each ticker's CIK |

## The rules

- **Headlines are leads, not facts.** Before telling the user something
  happened, open the story or the filing and read it. Quote the source and
  link it. Never summarise a paywalled story you could not read: say so.
- **Filings beat headlines.** If an 8-K and a headline disagree, the 8-K is
  what the company told the SEC.
- **Say what it touches.** Every item lists the tickers it touches and its
  tags: earnings, analyst, legal, deal, capital, people, risk, halt,
  regulatory, macro. Filings marked `!` carry an important 8-K item: earnings
  results (2.02), an officer change (5.02), an impairment (2.06), a delisting
  notice (3.01), past financials no longer reliable (4.02), bankruptcy (1.03)
  or a cyber incident (1.05).
- **MOVING** marks a stock 3 % or more from yesterday's close (`--move-pct`).
  A move with no headline is worth saying out loud too.
- **No predictions.** Report what was published and how far the price is from
  yesterday's close. Never say what the stock will do next.

## Steps

1. Run the check: `python3 "${CLAUDE_SKILL_DIR}/news.py"`. Exit code 1 means
   nothing new. `--all` shows items already seen, `--json` gives everything
   machine readable, `--dry-run` leaves the state alone.
2. Read the items that matter: every `!` filing, anything tagged earnings,
   halt, legal, regulatory or risk, and every MOVING ticker first.
3. Write a short brief, per ticker: what happened, the source and link, the
   move, and one line on why it matters to the setup (for example "earnings
   are this week: an overnight gap can jump past any stop").
4. If a story changes the picture, say so before `/trader-entry-NSE` and
   `/trader-exit-NSE`: an earnings date inside the trade, a halt, an offering.
   Never act on a headline alone.

During the session: `/loop 15m /trader-news-NSE`, or a scheduled task each
morning before the open.

## Example: the reel

Monday 2026-10-19, RELIANCE broke its opening range at 10:15 AM ET. The check at
10:15 (Yahoo Finance's RELIANCE feed, 16 headlines since 8:00) leads with the
morning's real stories: "Meta and Musk earnings and September pending home
sales: What to Watch" (8:00, earnings), "Tesla-SpaceX Merger Mania Strikes
Wall Street Ahead of Earnings" (8:04, earnings, deal), "Tech Stock Rebound
Nudges US Equity Futures Mostly Higher Pre-Bell" (8:02, macro). The brief:
"Tesla reports this week, so the stock can gap overnight; today's trade is
in and out before the close. No new 8-K." At 10:52 the price line reads
`RELIANCE 366.48 +3.31% vs yesterday's close 354.72 at 10:52 IST  MOVING`. When a
ticker has no news, say so rather than padding the brief.

## What it never does

- Never invents or embellishes a story, a quote or a number.
- Never trades on news, and never tells the user to buy or sell because of a
  headline.
- Never hammers a server: one request per feed per ticker, a pause between
  calls, and SEC's 10 requests a second limit stays far away.

## Safety

Education and tooling, not financial advice. This skill only reads and
reports. Nothing places an order except `/the broker step (not in this NSE edition)`, after
`/trader-risk-NSE` passes and the user types an explicit yes for that order.

## NSE edition notes (read first)

This is the India port of the original skill. What changed:

- **Market:** NSE equities, 9:15 to 15:30 IST, India time with no daylight saving. The opening range is 9:15 to 9:30 and the default entry window is 9:30 to 15:00.
- **Tickers:** type plain NSE symbols (RELIANCE, TCS, M&M, BAJAJ-AUTO). The scripts add `.NS` for Yahoo. Index names NIFTY and BANKNIFTY map to ^NSEI and ^NSEBANK.
- **Money:** rupees. Config keys that end in `_usd` (for example `max_loss_per_trade_usd`) mean rupees here; the names are kept so the original logic works. Prices sit on the NSE tick of Rs 0.05.
- **Holidays:** the 2026 list in the script is from public sources, not NSE's circular. Check it, and update it each December.
- **Data:** history comes from free Yahoo `.NS` charts. These can lag, so before acting on a trigger, check the live price with the Kite connector (`market` tool, mode `ltp` or `quote`). Kite's historical candles need a paid add-on, so they are not used.
- **Costs:** brokerage, STT, exchange fees and GST are NOT modelled. On small intraday moves they can turn a win into a loss.
- **Square-off:** most brokers auto-close intraday (MIS) positions around 15:20 to 15:25. The default flat-by time is 15:15.
- **No orders:** this edition is for analysis and testing. Nothing here places an order.
- **Not covered:** the SEC filings tool, the US Congress tracker and the Alpaca broker step are not ported.
- Not financial advice. Most people who day trade lose money.
